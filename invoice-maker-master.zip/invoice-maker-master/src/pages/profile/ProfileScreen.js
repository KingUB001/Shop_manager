import React from "react";

function ProfileScreen() {
  return <div>ProfileScreen</div>;
}

export default ProfileScreen;
