// module.exports = {
//     presets: ['@babel/preset-env'],
//     plugins: [],
//     ignore: ['node_modules'],
//     // add this line
//     parserOptions: {
//       sourceType: 'module',
//       "allowImportExportEverywhere": true

//     }
//   };