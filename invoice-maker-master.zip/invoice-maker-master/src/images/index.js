import invoice1 from "../images/1_bg.jpg" 
import invoice2 from "../images/2_bg.jpg" 
import invoice3 from "../images/3_bg.jpg" 
import invoice4 from "../images/4_bg.jpg" 
import invoice5 from "../images/5_bg.jpg" 
import invoice6 from "../images/6_bg.jpg" 
import invoice7 from "../images/7_bg.jpg" 




export {
    invoice1,
    invoice2,
    invoice3,
    invoice4,
    invoice5,
    invoice6,
    invoice7,
} ;
