import React, { useState } from "react";
import ReactDOM from "react-dom";
import { Navigate } from "react-router-dom";

import "./Login.css";

function Login() {
  // React States
  const [errorMessages, setErrorMessages] = useState({});
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [pass , setPass] = useState('')
  const [email , setEmail] = useState('')
  const [log , setLog] = useState([])
  const logi=()=>{
    const newlog = {id:new Date().getTime.toString(), email:email , pass:pass}
    setLog([...log,newlog])
  }

  


  // User Login info
  const database = [
    {
      username: "shop@owner.me",
      password: "2023@me",
    },
    {
      username: "Shop@employ.he",
      password: "2023@he",
    },
  ];

  const errors = {
    uname: "invalid username",
    pass: "invalid password",
  };
  var state=false
  const handleSubmit = (event) => {
    //Prevent page reload
    event.preventDefault();
    state=true
    logi();
    console.log(state)

    var { uname, pass } = document.forms[0];

    // Find user login info
    const userData = database.find((user) => user.username === uname.value);

    // Compare user info
    if (userData) {
      if (userData.password !== pass.value) {
        // Invalid password
        setErrorMessages({ name: "pass", message: errors.pass });
      } else {
        setIsSubmitted(true);
      }
    } else {
      // Username not found
      setErrorMessages({ name: "uname", message: errors.uname });
    }
  };

  // Generate JSX code for error message
  const renderErrorMessage = (name) =>
    name === errorMessages.name && (
      <div className="error">{errorMessages.message}</div>
    );

  // JSX code for login form
  const renderForm = (
    <div className="form">
      <form onSubmit={handleSubmit}>
        <div className="input-container">
          <label>Email </label>
          <input className="E-mail" value={email} type="text" name="uname" required onChange={(e)=> setEmail(e.target.value)}/>
          {renderErrorMessage("uname")}
        </div>
        <div className="input-container">
          <label>Password </label>
          <input className="pass" value={pass} type="password" name="pass" required onChange={(e)=> setPass(e.target.value)}/>
          {renderErrorMessage("pass")}
        </div>
        <div className="button-container">
          <input className="Submit" type="submit" value="Login"/>
        </div>
      </form>
    </div>
  );

  const fo = () =>{
    <Navigate replace to="/Dashboard" /> ;
    // document.getElementsByClassName("transition-all").style.display="block"
  }

  return (
    
    <div className="app">
      <div className="login-form">
        <div className="title">Sign In</div>
        {isSubmitted ? <Navigate replace to="/Dashboard" /> : renderForm}
      </div>
    </div>
    
  );
}

export default Login;

