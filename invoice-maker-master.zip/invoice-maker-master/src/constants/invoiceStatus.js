export const INVOICE = {
  Pending: {
    name: "Pending",
    index: 1,
  },
};
